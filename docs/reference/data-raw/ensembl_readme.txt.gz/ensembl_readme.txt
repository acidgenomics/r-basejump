===========

Ensembl Release 89 Databases.

THE ENSEMBL FTP SITE
====================

The latest data is always available via a directory prefixed "current_".
For example "current_fasta" will always point to the latest data files in FASTA format.

The FTP directory has the following basic structure, although not all information is available for each species.

|-- assembly_chain 	Chain files from Ensembl assembly records
|
|-- bamcov      BAM and BigWig files derived by aligning RNASeq data to the genome 
|
|
|-- bed         GERP constrained element data in BED format 
|
|
|-- compara     TreeFam HMM families
|
|
|-- data_files  Browse alignment data files by species and assembly
|
|
|-- embl        Gene predictions annotated on genomic DNA slices of 1MB in EMBL format
|    |
|    |-- species
|
|
|-- emf         Alignment dumps in EMF format
|    |
|    |-- ensembl_compara    * protein trees and protein multiple alignments underlying othologue/paralogue alignments
|          |
|          |-- pecan        * Pecan whole genome multiple alignments with conservation scores for selected sets
|          |-- epo          * EPO whole genome multiple alignments with conservation scores for selected sets
|    
|    
|   
|-- fasta       Gene Predictions in FASTA format
|    |
|    |-- ancestral alleles   * Predictions of the ancestral alleles (coordinates correspond to each extant species)   
|    |
|    |-- species
|        |
|        |-- cdna      * Transcript (cDNA) predictions
|	 |-- cds       * Coding sequences
|        |-- dna       * Genomic DNA in assembled entities
|        |-- pep       * Translation (peptide) predictions
|        |-- rna       * Non-coding RNA predictions
|  
|
|-- genbank     Gene predictions annotated on genomic DNA slices of 1MB in GenBank format
|    |
|    |-- species
|
|
|-- gtf         Gene annotation in GTF format
|
|
|-- gff3        Gene annotation in GFF3 format
|
|
|-- regulation  GFF files representing reatures built by the Ensembl Regulatory build
|     |
|     |--species    
|
|
|-- solr_search         Indices and configuration files for Ensembl Solr Search
|
|
|
|
|-- variation   Variations in GVF format, VCF format and Variant Effect Predictor data
|    |
|    |-- gvf   * Variations in GVF format
|    |
|    |-- vcf   * Variations in VCF format
|    |
|    |-- VEP   * Cache files for use with the VEP script
|         
|         
|
|-- virtual machine   Ensembl virtual machine
|
|
|-- xml         Alignment dumps in XML format
|    |
|    |-- ensembl-compara  * protein and ncRNA trees and multiple alignments underlying othologue/paralogue alignment
|          |
|          |-homologies
|
|
|-- maf         Alignment dumps in MAF format
|    |
|    |-- ensembl-compara
|          |
|          |-- multiple_alignments
|          |       |-- pecan        * Pecan whole genome multiple alignments
|          |       |-- epo          * EPO whole genome multiple alignments
|          |
|          |-- pairwise_alignments  * LastZ pairwise alignments between human (GRCh38) and all other Ensembl species
|
|
|-- rdf		Ensembl genes and external references in RDF format
|
|
|-- tsv         Cross references between Ensembl genes, transcripts and translations
|               to UniProt and ENA in Tab Separated Value format
|
|
|-- mysql       MySQL database table text dumps
     |
     |-- core   General genome annotation information
     |
     |          * Genome sequence asembly
     |          * Ensembl gene predictions
     |          * Ab initio gene predictions
     |          * Marker information
     |          * ...
     |
     |-- otherfeatures      Additional genome annotation
     | 
     |          * Gene predictions based on EST information
     |          * ...
     |
     |-- rnaseq     Gene models built from rnaseq data
     |
     |-- variation  Genetic variation information
     |
     |-- funcgen    Regulation information
     |
     |-- vega       Manually curated gene sets  
     |
     |-- cdna       cDNA to genome alignments based on the latest EMBL databases
     |
     |-- ensembl_compara    Cross-species comparative genomics data:
     |
     |          * Orthologue/paralogue predictions
     |          * Protein families
     |          * Whole genome alignments
     |          * Synteny information
     |
     |-- ensembl_ontology     Gene Ontology database
     |
     |-- ensembl_web_user_db  SQL table definition for server-side user config database
     |
     |-- ensembl_website      Ensembl web site database
     |
     |          * Context-sensitive help articles
     |          * News articles
     |          * Mini-ads
     |
     |-- ensembl-mart Cross-species data mining tables 
     |
     |-- regulation_mart   Regulation data
     |
     |-- genomic_features_mart      Clone data sets
     |
     |-- ontology_mart  Ontology
     |
     |-- sequence_mart  Genome sequences
     |
     |-- snp_mart       Genetic variation information
     |
     |-- vega_mart      Manually curated gene sets

